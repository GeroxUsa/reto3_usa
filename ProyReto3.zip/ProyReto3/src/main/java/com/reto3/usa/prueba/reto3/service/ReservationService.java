/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.reto3.usa.prueba.reto3.service;

import com.reto3.usa.prueba.reto3.entity.Reservation;
import com.reto3.usa.prueba.reto3.repository.ReservationRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Gerox
 */

@Service
public class ReservationService {
    @Autowired
    private ReservationRepository repositorio;
    
    // CRUD Create, Read, Update, Delete
    // Create
    public Reservation saveReservation(Reservation reservation){
        return repositorio.save(reservation);
    }
    //Read
    public List<Reservation> getReservationAll(){
        return repositorio.findAll();
    }
    //Update
    public Reservation updateReservation(Reservation reservation){
        Reservation existeReservation=repositorio.findById(reservation.getId()).orElse(null);
        existeReservation.setStartDate(reservation.getStartDate());
        existeReservation.setDevolutionDate(reservation.getDevolutionDate());
//        existeMessage.s(message.getEmail());
//        existeMessage.setPassword(message.getPassword());
        return repositorio.save(existeReservation);
    }
    //Delete
    public String deleteReservation(int id){
        repositorio.deleteById(id);
        return "Registro con id "+id+" ha sido eliminado";
    }
    
    //Filtro por ID
    public Reservation getReservationById(Reservation reservation){
        return repositorio.findById(reservation.getId()).orElse(null);
    }
}
