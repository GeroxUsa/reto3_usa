/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.reto3.usa.prueba.reto3.controller;

import com.reto3.usa.prueba.reto3.entity.Reservation;
import com.reto3.usa.prueba.reto3.service.ReservationService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Gerox
 */

@RestController
@RequestMapping("/api/Reservation/")
public class ReservationController {
    @Autowired
    private ReservationService servicio;

    @GetMapping("/all")
    public List<Reservation> findAllReservation() {
        return servicio.getReservationAll();
    }

    @PostMapping("/save")
    public ResponseEntity addReservation(@RequestBody Reservation reservation) {
        servicio.saveReservation(reservation);
        return ResponseEntity.status(201).build();
    }
}
